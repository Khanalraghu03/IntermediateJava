package chapter20;

import java.util.Scanner;

/**
 * @author Raghu Khanal
 *
 */

public class TestMakeMaze {
    public static void main(String[] args) {
    //•	Implement the main() method as follows:
        //•	Create a Scanner (input) to get user input from the keyboard.
        Scanner input = new Scanner(System.in);
        //•	Prompt the user for the filename for the maze and store it in a String (filename).
        System.out.print("Please enter the file name(with the extensions): ");
        String filename = input.nextLine();
        //•	Prompt the user for the width of the maze in pixels and store it in an int (width).
        System.out.print("Please enter the maze width in pixels: ");
        int mazeWidth = Integer.parseInt(input.nextLine());
        //•	Prompt the user for the height of the maze in pixels and store it in an int (height).
        System.out.print("Please enter the maze height in pixels: ");
        int mazeHeight = Integer.parseInt(input.nextLine());
        //•	Prompt the user for the numberOfMazes in pixels and store it in an int (numberOFMazes).
        System.out.print("Please enter the number of mazes in pixels: ");
        int numberOfMazes = Integer.parseInt(input.nextLine());

        //•	Create an object of class Maze and pass filename, height and width by adding the following code: new Maze(filename,width,height,numberOfMazes);
        MakeMaze maze = new MakeMaze(filename,mazeWidth,mazeHeight,numberOfMazes);
        //•	Close input.
        input.close();

        //Enter the dimensions of the maze as 500 X 500 pixels.
        //The maze data (0s) should appear on the console.
        // At this point the GUI will open showing only the window and button.
        // The maze will not be shown.


    }
}

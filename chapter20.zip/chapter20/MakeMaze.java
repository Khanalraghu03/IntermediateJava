package chapter20;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.*;

/**
 * @author Raghu Khanal
 *
 */

public class MakeMaze extends JPanel implements ActionListener {
    //A MyLinkedList object to store Integer objects.
    //A MyLinkedList will store Integers (1s and 0s).
    private MyLinkedList<Integer> list;
    //A stack to store Rectangle objects.
    private Stack<Rectangle> stack;
    //A PriorityQueue to store MyLinkedLists of Integer.
    private PriorityQueue<MyLinkedList<Integer>> priorityQueue;
    private String fileName;
    int mazeWidth;
    private  int mazeHeight;
    private int numberOfMazes;
    private Random random;
    private volatile boolean wait;

    //Two dimensional (2D) array to store the 1s and 0s.
    //A 2D array is an array in which elements are
    //logically stored and accessed in rows and columns similar
    //to a 2D matrix or grid.
    private int[][] maze;
    //Variable to store coordinates for the entrance to the maze
    private int x;
    private int y;
    //A constant for the milliseconds to be delayed
    public final static long MSECS = 10;
    //The following instance variables are also required:
    private JFrame frame;
    private JPanel panel;
    private JPanel panel1;
    private JButton button;

    public static final long serialVersionUID = 1L;

    public MakeMaze(String filename, int mazeWidth, int mazeHeight, int numberOfMazes) {
        this.fileName = filename;
        this.mazeWidth = mazeWidth;
        this.mazeHeight = mazeHeight;
        this.numberOfMazes = numberOfMazes;
        //�	It creates a Stack and assigns it to the instance variable.
        stack = new Stack<>();
        //�	It creates a PriorityQueue and assigns it to the instance variable.
        priorityQueue = new PriorityQueue<>();
        //�	It creates a default Random object and assigns it to the instance variable.
        random = new Random();
        //�	 It assigns true to the instance variable wait
        wait = true;
        //�	It calls the readMazeFromFile() method.
        readMazeFromFile();
        //�	Creates the GUI (see the screenshot on page 5. At this point, create only the window and the button.
        panel = new JPanel(new BorderLayout());
        panel1 = new JPanel();
        button = new JButton("Make Maze");

        panel1.add(button);
        panel.add(this);
        frame = new JFrame("Maze");
        this.frame.setSize(mazeWidth + 100, mazeHeight + 100);
        frame.add(panel);
        panel.add(panel1, BorderLayout.SOUTH);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        frame.setResizable(false);

        //      The maze will be drawn later). The frame size should be mazeWidth+100 X mazeHeight+100.
        //�	Handles the button click event.
        //�	Add a while-loop that continuously iterates to stall the program until wait is set to true.

        while(wait)
//            while (true);
            //�	Add a for-loop that iterates for numberOfMazes. Code the following statements in the loop.
            for (int i = 0; i < numberOfMazes; i++) {
                //o	It calls the reset() method. This method will be implemented later.
            reset();
            repaint();

                //o	Delays for 10 msecs.
                try {
                    Thread.sleep(10);
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                    System.out.println("Error @ Line: 81");
                }
                //o	Calls makePath(stack, maze, x, y), makeMultiplePaths(), makeOpenings() and enqueue().
            makePath(stack, maze, x, y);
            makeMultiplePaths();
            makeOpenings();
            enqueue();
            repaint();
                //o	Delays for 20msecs
                try {
                    Thread.sleep(20);
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                    System.out.println("Error @ Line: 81");
                }
                //�	End for-loop


            }
        dequeue();
        repaint();
        writeMazeToFile();
        }



    public MyLinkedList<Integer> getList() {
        return list;
    }

    public void setList(MyLinkedList<Integer> list) {
        this.list = list;
    }

    public Stack<Rectangle> getStack() {
        return stack;
    }

    public void setStack(Stack<Rectangle> stack) {
        this.stack = stack;
    }

    public PriorityQueue<MyLinkedList<Integer>> getPriorityQueue() {
        return priorityQueue;
    }

    public void setPriorityQueue(PriorityQueue<MyLinkedList<Integer>> priorityQueue) {
        this.priorityQueue = priorityQueue;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public int getMazeWidth() {
        return mazeWidth;
    }

    public void setMazeWidth(int mazeWidth) {
        this.mazeWidth = mazeWidth;
    }

    public int getMazeHeight() {
        return mazeHeight;
    }

    public void setMazeHeight(int mazeHeight) {
        this.mazeHeight = mazeHeight;
    }

    public int getNumberOfMazes() {
        return numberOfMazes;
    }

    public void setNumberOfMazes(int numberOfMazes) {
        this.numberOfMazes = numberOfMazes;
    }

    public int[][] getMaze() {
        return maze;
    }

    public void setMaze(int[][] maze) {
        this.maze = maze;
    }

    @Override
    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    @Override
    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }


    @Override
    public String toString() {
        return "MakeMaze{" +
                "list=" + list +
                ", stack=" + stack +
                ", priorityQueue=" + priorityQueue +
                ", fileName='" + fileName + '\'' +
                ", mazeWidth=" + mazeWidth +
                ", mazeHeight=" + mazeHeight +
                ", numberOfMazes=" + numberOfMazes +
                ", maze=" + Arrays.toString(maze) +
                ", x=" + x +
                ", y=" + y +
                '}';
    }


    //Implement method +readMazeFromFile(): void
    public void readMazeFromFile() {
        //�	It creates a File object (file) with the filePath and filename (use the instance variable fileName) to read a maze from a text file in the folder Maze_Data on the Desktop.
        File filePath = new File(System.getProperty("user.home") + File.separatorChar + "desktop"
                + File.separatorChar + "Maze_Data" + File.separatorChar + fileName);
        //�	Create a Scanner (fileIn) to read the file. Handle any Exceptions by printing the stack trace.
        Scanner fileIn = null;
        //�	Declare a String (line) and initialize it to an empty String.
        String line = "";

        //�	Declare an int countRows and initialize it to zero.
        //      This variable will be used to store the number of rows of the binary maze.
        int countRows = 0;
        try {
            fileIn = new Scanner(filePath);
            //�	Count the number of rows using the following code:
            while(fileIn.hasNextLine()){
                line = fileIn.nextLine();
                countRows++;
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        //�	Close input.
        fileIn.close();
        //�	Declare an int countColumns and initialize it to (line.length()+1)/2.
        //      This expression computes the number of columns by taking into account that
        //       there are spaces in each row of the file.
        int countColumns = (line.length() + 1)/2;
        //�	Create a 2D Array using the following code: maze = new int [countRows][countColumns];
        maze = new int[countRows][countColumns];
        //�	Create a Scanner (readMaze) to read the file. Handle any Exceptions by printing the stack trace.
        Scanner readMaze = null;
        try {
            readMaze = new Scanner(filePath);
            //�	Read the data from the file into maze using the following code:
            for(int i = 0; i < maze.length; i++){
            	for(int j = 0; j < maze[i].length; j++){
            		maze[i][j]= readMaze.nextInt();
            	}
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        //�	Close readMaze.
        readMaze.close();
        //�	Display the maze using the following code:
        for(int i = 0; i < maze.length; i++){
        		System.out.println(Arrays.toString(maze[i]));
        }

    }



    //
//Implement the following method in the class to color the Rectangles that form the paths and walls of //the maze
//    Implement method +paintComponent(g: Graphics): void
    public void paintComponent(Graphics g) {
        //    Call the paintComponent(g) from the super class
        super.paintComponent(g);
//        Use the following algorithm to draw the maze
//                        Nested loops for (i,j) until all ints in the maze are visited
        for(int i = 0; i < maze.length; i++) {
            for(int j = 0; j < maze[i].length; j++) {

                //This color coding is used to identify the walls in the maze
                if(maze[i][j] == 0) {
                    // setColor to black
                    g.setColor(Color.BLACK);
                }

                else if(maze[i][j] == 4) {
                    //This color coding is used to identify the path currently being traversed
                    // setColor to light grey
                    g.setColor(Color.lightGray);
                }

                else {
                    //int is 1. This color coding is used to identify all the paths in the maze
                    // setColor to white
                    g.setColor(Color.WHITE);
                }

//        //Draw the rectangle with computed x-coordinate, y-coordinate, width and height based on j, i,
//          mazeWidth and mazeHeight
                //The first parameter is the x coordinate of the top left corner of the rectangle to be drawn
                //The second parameter is the y coordinate of the rectangle
                //The third and forth coordinates are the width and height of the rectangle respectively
                g.fillRect(j*(mazeWidth/maze[0].length)+40,i*(mazeHeight/maze.length)+30,
                    mazeWidth/maze[0].length, mazeHeight/maze.length);

            }
        }
    }


    @Override
    public void actionPerformed(ActionEvent arg0) {
        wait = false;
    }

    // Implement the following method in the class to select the initial x and y coordinates to begin drawing //the maze. The method also resets the ints in the 2D array to 0s
    //Implement method +reset(): void
    public void reset() {
        //Assign a random int between 1 and maze[0].length-2 (both inclusive) to x
        x = random.nextInt(maze[0].length -2)+1;
        //Assign a random int between 1 and maze[0].length-2 (both inclusive) to y
        y = random.nextInt(maze[0].length -2)+1;

        for(int i = 0; i < maze.length; i++) {
            for(int j = 0; j < maze[i].length; j++) {
                maze[i][j] = 0;
            }
        }
    }

    //// Implement the following method in the class to redraw the maze and delay to clearly observe the //path progression
    //Implement method +repaintAndDelay(): void
    public void repaintAndDelay() {
        //Call the repaint method
        repaint();
        //Delay for MSECS
        try{
            Thread.sleep(MSECS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


    ////Implement the following method to draw the maze
    //Implement recursive method +makePath(stack: Stack <Rectangle>, maze: int [][], j: int, i: int): void
    public void makePath(Stack<Rectangle> stack, int[][] maze, int j, int i) {
        //If i or j fall on or outside the boundaries of the 2D Array
        if(i <= 0 || i >= maze.length -1 || j <= 0 || j >= maze[i].length-1) {
            //	Return
            return;
        }


       ////Explanation for following pseudocode statement: If a path is encountered or an Array slot in the path is
        ////already visited, return from the method
        //If maze[i][j] is equal to 1 or 4
        if(maze[i][j] == 1 || maze[i][j] == 4) {
            return;
        }


        ////Explanation for following pseudocode statement: Code the path with integer 4, so that
        ////it will be colored light gray in the graphical maze be highlighted as visited
        //Assign 4 to maze[i][j]
        maze[i][j] = 4;
        stack.push(new Rectangle(i,j,mazeWidth/maze[0].length,
                mazeHeight/maze.length));
        this.repaintAndDelay();
        int random1 = random.nextInt(4);
        
        ////Explanation for following pseudocode statement: So that the path progresses randomly, decide with a //25% chance to visit the Array cells to the left, above, to the right or below the current Array cell at i, j, //and proceed to visit the other 3 cells in a clockwise direction
        //Declare an int random1 and assign to it a random int between 0 and 3 (both inclusive)
        //If random1 is equal to 0
        if(random1 == 0) {
            //In the following order call methods moveLeft, moveUp, moveRight and moveDown,
            // and pass i and j. Comment the methods they will be implemented later.
        	moveLeft(i, j);
        	moveUp(i,j);
        	moveRight(i,j);
        	moveDown(i,j);

        }
        //

        else if (random1 == 1) {
            //	In the following order call moveUp, moveRight, moveDown and moveLeft, and pass i and j
        	moveLeft(i, j);
        	moveUp(i,j);
        	moveRight(i,j);
        	moveDown(i,j);
        }

        else if(random1 == 2) {
            //	In the following order call moveRight, moveDown, moveLeft and moveUp, and pass i and j
        	moveLeft(i, j);
        	moveUp(i,j);
        	moveRight(i,j);
        	moveDown(i,j);
        }

        else {
            //	In the following order call moveDown, moveLeft, moveUp and moveRight, and pass i and j
        	moveLeft(i, j);
        	moveUp(i,j);
        	moveRight(i,j);
        	moveDown(i,j);
        }
        
        //If stack is not empty
        if(!stack.isEmpty()) {
        	 //	Declare a variable rWall of type Rectangle and pop a Rectangle from stack and assign it to rWall
        	Rectangle rWall = stack.pop();
            ////Explanation for following pseudocode statement: Code the path with integer 1, so that it will
            ////	be colored white in the graphical maze as the method backtracks after encountering a wall
        	maze[rWall.getX()][rWall.getY()] = 1;
        	repaintAndDelay();
        	//If stack is not empty
            //		Declare a variable rPath of type Rectangle and pop a Rectangle from stack and assign it to rPath
            ////Explanation for following pseudocode statement: Code the path with integer 1, so that //it will be colored white in the graphical maze as the method backtracks after //encountering an Array slot in the path that is already visited
            //Assign 1 to maze[value of x from rPath][value of y from rPath]
            //
            //Call the repaintAndDelay method to redraw the maze to see backtracking to the previous slot
   
        	if(!stack.isEmpty()) {
        		 Rectangle rPath = stack.pop();
        		 maze[rPath.getX()][rPath.getY()] = 1;
        		 repaintAndDelay();
        	 }
        	
        }
        
    }
    
    public void moveLeft(int i, int j) {
    	if(!(i<=0||i>=maze.length-1||j-2<=0||j-2>=maze[0].length-1||maze[i][j-2]==4||maze[i][j-2]==1)) {
    		//Mark the Array cell at 	maze[i][j-1] as visited
    		maze[i][j-1] = 4;
    		
    	//Explanation for following pseudocode statement: Continue storing the path being drawn by //pushing a Rectangle corresponding to the left Array slot onto stack
    		stack.push(new Rectangle(i,j-1, mazeWidth/maze[0].length,mazeHeight/maze.length));

//    	Call the repaintAndDelay method to redraw the maze to see the path progress to the left slot
	    	repaintAndDelay();
	    	makePath(stack, maze, j-2, i);

    	}
    }
    
  //Implement the following method to move to the Up Array slot
//    Implement method +moveUp(i: int, j: int): void
    	public void moveUp(int i, int j) {
//    	    // If i-2 or j fall inside the boundaries of the 2D Array and maze[i-2][j] is not visited or maze[i-2][j] is not a //path

    	    if(!(i-2<=0||i-2>=maze.length-1||j<=0||j>=maze[0].length-1||maze[i-2][j]==4||maze[i-2][j]==1))	 {
    	    	//Mark the Array cell at 	maze[i-1][j] as visited
    	    	maze[i-1][j] = 4;
    	//
//    	    //Explanation for following pseudocode statement: Continue storing the path being drawn by //pushing a Rectangle corresponding to the Up Array slot onto stack
//    	    Push new Rectangle(i-1,j, mazeWidth/maze[0].length,mazeHeight/maze.length) on to stack
    	    	stack.push(new Rectangle(i-1,j, mazeWidth/maze[0].length,mazeHeight/maze.length));
    	//
//    	    Call the repaintAndDelay method to redraw the maze to see the path progress to slot above
    	    	repaintAndDelay();
    	    	makePath(stack, maze, j, i-2);
//    	    End if
    	    }
//    	    
    	}


    ////Implement the following method to move to the right Array slot
//    Implement method +moveRight(i: int, j: int): void
    	public void moveRight(int i, int j) {
//
	// // If i or j+2 fall inside the boundaries of the 2D Array and maze[i][j+2] is not visited or maze[i][j+2] is not //a path
	    	if(!(i<=0||i>=maze.length-1||j+2<=0||j+2>=maze[0].length-1||maze[i][j+2]==4||maze[i][j+2]==1)) {
	    	//Mark the Array cell at 	maze[i][j+1] as visited
	    	//  Assign 4 to maze[i][j+1]
	    		maze[i][j+1] = 4;
	    	//
	    	// //Explanation for following pseudocode statement: Continue storing the path being drawn by //pushing a Rectangle corresponding to the Right Array slot onto stack
	    	// Push new Rectangle(i,j+1, mazeWidth/maze[0].length,mazeHeight/maze.length) on to stack
	    		stack.push(new Rectangle(i,j+1, mazeWidth/maze[0].length,mazeHeight/maze.length));
	    	//
	    	// Call the repaintAndDelay method to redraw the maze to see the path progress to the right slot
	    		repaintAndDelay();
	//    	 	Call makePath(stack, maze, j+2, i)
	    		makePath(stack, maze, j+2, i);
	    	// End if
	    	}


    	}
    
    
  //Implement the following method to move to the Down Array slot
//    Implement method +moveDown(i: int, j: int): void
    	public void moveDown(int i, int j) {
//    	    // If i+2 or j fall inside the boundaries of the 2D Array and maze[i+2][j] is not visited or maze[i+2][j] is not //a path
    	    if(!(i+2<=0||i+2>=maze.length-1||j<=0||j>=maze[0].length-1||maze[i+2][j]==4||maze[i+2][j]==1)) {
    	    	
//        	    //Mark the Array cell at 	maze[i+1][j] as visited
//    	    	Assign 4 to maze[i+1][j]
    	    	maze[i+1][j] = 4;
    	//
//    	    //Explanation for following pseudocode statement: Continue storing the path being drawn by //pushing a Rectangle corresponding to the Down Array slot onto stack
//    	    Push new Rectangle(i+1,j, mazeWidth/maze[0].length,mazeHeight/maze.length) on to stack
    	    	stack.push(new Rectangle(i+1,j, mazeWidth/maze[0].length,mazeHeight/maze.length));
    	//
//    	    Call the repaintAndDelay method to redraw the maze to see the path progress to the down slot
    	    	repaintAndDelay();
//    	    	Call makePath(stack, maze, j, i+2)
    	    	makePath(stack, maze, j, i+2);
//    	    End if
    	    	
    	    }

    	}


    
    
    
    ////Implement the following method to add the ints in the maze to a LinkedList and then add the //LinkedList to a PriorityQueue
//	Implement method +enqueue(): void
    	public void enqueue() {
    		//	Create a MyLinkedList<> object and assign its reference to list.
    		MyLinkedList<Integer> object = list;
//    		Nested loops for (i,j) until all ints in the maze are added to list
//    			Add list to priorityQueue.
    	//	
    	//	
    		
    	}

//	//Implement the following method to remove the LinkedList with the maximum path area from the //PriorityQueue and add the ints in the LinkedList to the maze
//	Implement method +dequeue(): void
    	public void dequeue() {
//    		If the priorityQueue is not empty
    		if(!priorityQueue.isEmpty()) {
//    			Remove the LinkedList form the priorityQueue and assign it to list

    	    	//	Nested loops for (i,j) until all ints in list are removed and added to the maze
    		}


    		
    	}
	
//	//Implement the following method to create multiple paths between one opening and the other in the //maze
//	Implement method +makeMultiplePaths(): void
    	public void makeMultiplePaths() {
    		
//    		Nested loops for (i,j) until all slots in the 2D array are visited
//    		// If i or j fall inside the boundaries of the 2D 
    		for(int i = 0; i < maze.length; i++) {
    			for(int j = 0; j < maze[i].length; j++) {
    	    		if(!(i<=1||i>=maze.length-2||j<=1||j>=maze[i].length-2)) {
//        				//With a 1% chance assign 1 to an Array slot
//    	        		If a random number generated between 0 and 99 (both inclusive) is equal to 50
//    	        			Assign 1 to the Array slot
    	    				if(random.nextInt(100) == 50) {
    	    					
    	    					maze[i][j] = 1;
    	    				}
    	    			
    	    		}

    			}
    			
    		}

    		
    	}

//	//Implement the following method to create two openings in the maze
//	Implement method +makeOpenings(): void
    	public void makeOpenings() {
//    		//With a 50% chance create openings randomly on the left and right boundaries of the maze 
//    		If a random number generated (0 or 1) is equal to 0
    		if(random.nextInt(2) == 0) {
    			int i1 = random.nextInt(maze.length - 8) + 4;
    			int j1 = 0;
    			int i2 = random.nextInt(maze.length-8)+4;
    			int j2 = maze[0].length -1;
    			

//    			//Use the following code to create the openings on the left and right sides of the maze
    			while(maze[i1][j1]!=1){
    				maze[i1][j1++]=1;
    			}
    			while(maze[i2][j2]!=1){
    				maze[i2][j2--]=1;
    			}
//    		End if
    		}

    	//	//With a 50% chance create openings randomly on the top and bottom boundaries of the maze 
//    		Else 
    		else {
    			//the random number generated (0 or 1) is equal to 1
//        		Declare an int (i1) and assign to it 0
    			int i1 = 0;
//        		Declare an int (j1) and assign to it a random number generated between 4 and maze[0].length-5 (both inclusive).
    			int j1 = random.nextInt(maze[0].length -5) + 4;
//        			Declare an int (i2) and assign to it maze.length-1
    			int i2 = maze.length -1;
//        						
//        		Declare an int (j2) and assign to it a random number generated between 4 and maze[0].length-5 (both inclusive).
    			int j2 = random.nextInt(maze[0].length -5) +4;
//        					
//        			//Use the following code to create the openings on the left and right sides of the maze
        				while(maze[i1][j1]!=1){
        					maze[i1++][j1]=1;
        				}
        				while(maze[i2][j2]!=1){
        					maze[i2--][j2]=1;
        				}
//        		End Else
    			
    			
    		}
    
//    		
    		
    	}



//	Implement method +writeMazeToFile(): void
    	public void writeMazeToFile() {
//    		�	It creates a File object (file) with the filePath and filename (use the instance variable fileName) to write the maze to a text file in the folder Maze_Data on the Desktop.
    		File file = new File(System.getenv("user.home")
    				+ File.separatorChar + "desktop" + File.separatorChar
    				+ File.separatorChar+ "Maze_Data" +fileName);
    		//  �	Create a PrintWriter (output) to write to the file. Handle any Exceptions by printing the stack trace.
    		PrintWriter output = null;
			try {
				output = new PrintWriter(file);
//				
			}catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
//			�	Write the maze to the file using the following code:
	    		for(int i = 0; i < maze.length; i++){
	    				for(int j = 0; j < maze[i].length; j++){
	    					if(j<maze[i].length-1)
	    						output.print(maze[i][j]+" ");
	    					else
	    						output.print(maze[i][j]);
	        					output.println();
	    				}
	    		} 
			if(output != null) {
				output.close();
			}
			
//    		

    			
//    		�	Close output.
    		
//    		�	Display the maze using the following code:
    		for(int i = 0; i < maze.length; i++){
    				System.out.println(Arrays.toString(maze[i]));
    	}
    		
    		
    	}

}





package project;

public class Practice {
    public static void main(String[] args) {
        long num = (long) Math.pow(2,64) -1 ;
        System.out.println(num);
        //9,223,372,036,854,775,807 - 1 = 9223372036854775806
    }
}
